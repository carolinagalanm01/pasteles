function mostrarSeccion(id) {
  const secciones = document.querySelectorAll("main > section");
  secciones.forEach(sec => sec.style.display = "none");
  document.getElementById(id).style.display = "block";
}

const productos = {
  pasteles: [
    { nombre: "Pastel de Chocolate", precio: 250 },
    { nombre: "Pastel de Fresa", precio: 230 }
  ],
  gelatinas: [
    { nombre: "Gelatina Tricolor", precio: 70 },
    { nombre: "Gelatina de Mosaico", precio: 80 }
  ],
  pays: [
    { nombre: "Pay de Limón", precio: 90 },
    { nombre: "Pay de Queso", precio: 100 }
  ]
};

function mostrarCategoria(categoria) {
  const cont = document.getElementById("categoria-productos");
  cont.innerHTML = "";
  productos[categoria].forEach((p, i) => {
    cont.innerHTML += `
      <div>
        <h3>${p.nombre}</h3>
        <p>Precio: $${p.precio}</p>
        <button onclick="agregarAlCarrito('${categoria}', ${i})">Agregar al carrito</button>
      </div>
    `;
  });
}

const carrito = [];

function agregarAlCarrito(cat, idx) {
  carrito.push(productos[cat][idx]);
  actualizarCarrito();
}

function actualizarCarrito() {
  const lista = document.getElementById("lista-carrito");
  const total = document.getElementById("total-carrito");
  lista.innerHTML = "";
  let suma = 0;
  carrito.forEach((item, i) => {
    suma += item.precio;
    lista.innerHTML += `<li>${item.nombre} - $${item.precio}
      <button onclick="borrarProducto(${i})">Eliminar</button>
    </li>`;
  });
  total.textContent = suma;
}

function borrarProducto(i) {
  carrito.splice(i, 1);
  actualizarCarrito();
}

function descargarTicket() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const fecha = new Date();
  const fechaStr = fecha.toLocaleDateString();
  const horaStr = fecha.toLocaleTimeString();
  const metodo = document.getElementById("metodoPago").value;

  doc.text("Ticket de compra - Pastelería Las Nubes", 10, 10);
  doc.text(`Fecha: ${fechaStr} - Hora: ${horaStr}`, 10, 20);

  carrito.forEach((item, i) => {
    doc.text(`${i + 1}. ${item.nombre} - $${item.precio}`, 10, 30 + i * 10);
  });

  const total = carrito.reduce((acc, val) => acc + val.precio, 0);
  doc.text(`Total: $${total}`, 10, 40 + carrito.length * 10);
  doc.text(`Método de Pago: ${metodo}`, 10, 50 + carrito.length * 10);

  doc.save("ticket_pasteleria.pdf");
}
